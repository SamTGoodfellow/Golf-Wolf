## Packages
framer-motion | Smooth animations for page transitions and interactive elements
canvas-confetti | Celebration effects for winning
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
